let socket = null;
let wsUrl = "";
let isReconnection = false;

const onmessageWS = (event) => {
  const { data } = event;
  if (data) {
    self.postMessage(data, [data]);
  }
};
const onopenWs = () => {};

const onerrorWS = () => {
  self.postMessage({ offline: true });
  isReconnection = true;
  socket.close();
  if (socket.readyState !== 3) {
    socket = null;
    createSocket(wsUrl);
  }
};
const oncloseWS = () => {
  if (socket.readyState !== 2) {
    socket = null;
    if (isReconnection) {
      createSocket(wsUrl);
    }
  }
};

function createSocket(url) {
  wsUrl = url;
  if (socket) {
    isReconnection = true;
    socket.close();
  }
  if (!socket) {
    socket = new WebSocket(url);
    socket.binaryType = "arraybuffer";
    socket.onmessage = onmessageWS;
    socket.onerror = onerrorWS;
    socket.onclose = oncloseWS;
  } else {
    console.log("websocket");
  }
}

function closeSocket() {
  if (socket) {
    isReconnection = false;
    socket.close();
  }
}

self.addEventListener("message", (e) => {
  const { data } = e;
  if (data.type === "open") {
    wsUrl = data.url;
    createSocket(wsUrl);
  } else if (data.type === "close") {
    closeSocket();
  }
});
